/**
 * server.js
 * Self-contained backend for Tambola-Game (file-based persistence).
 *
 * - Serves static Admin/ and Game/ folders
 * - API endpoints for admin and game
 * - Generates correct Tambola tickets (3x9 grid, column ranges)
 * - Draws numbers, detects winners (Quick Five, Line1, Line2, Line3, Full House)
 * - Auto-calls numbers every 10s when game is running (server timer)
 * - SSE (EventSource) for live updates to connected players
 *
 * Defaults:
 *   admin user: Komo
 *   admin pass: Komo123
 */

const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data.json');
const ADMIN_USER = process.env.ADMIN_USERNAME || 'Komo';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'Komo123';
const ADMIN_TOKEN = 'admintoken-demo-xyz'; // simple static token for demo, change if needed
const TICKET_PRICE = 20;
const GAME_CHARGE = 20;
const AUTO_CALL_INTERVAL_MS = 10000; // 10s

// Prize distribution (your final spec)
const DISTRIBUTION = {
  quickFivePct: 15,
  line1Pct: 15,
  line2Pct: 15,
  line3Pct: 15,
  fullHousePct: 40
};

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontends
app.use('/Admin', express.static(path.join(__dirname, 'Admin')));
app.use('/Game', express.static(path.join(__dirname, 'Game')));

// In-memory SSE clients
const sseClients = [];

// Load / save simple JSON store
let store = { games: [] };

function loadStore() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } else {
      saveStore();
    }
  } catch (e) {
    console.error('Failed to load store', e);
    store = { games: [] };
    saveStore();
  }
}

function saveStore() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2));
}

// Helper: calc prizes
function calcPrizes(ticketCount) {
  const totalRevenue = ticketCount * TICKET_PRICE;
  const totalPrize = totalRevenue - GAME_CHARGE;
  const round = n => Math.round(n);
  let q = round(totalPrize * (DISTRIBUTION.quickFivePct / 100));
  let l1 = round(totalPrize * (DISTRIBUTION.line1Pct / 100));
  let l2 = round(totalPrize * (DISTRIBUTION.line2Pct / 100));
  let l3 = round(totalPrize * (DISTRIBUTION.line3Pct / 100));
  let fh = round(totalPrize * (DISTRIBUTION.fullHousePct / 100));
  const sum = q + l1 + l2 + l3 + fh;
  const residue = totalPrize - sum;
  fh += residue; // add rounding residue to full house
  return {
    totalRevenue,
    totalPrize,
    prizeAmounts: { quickFive: q, line1: l1, line2: l2, line3: l3, fullHouse: fh }
  };
}

// Ticket generator using classic column ranges 1-9,10-19,...80-90
function generateTicket(idPrefix, idx) {
  // create buckets for columns
  const columns = [
    range(1,9), range(10,19), range(20,29), range(30,39),
    range(40,49), range(50,59), range(60,69), range(70,79), range(80,90)
  ];
  // shuffle each column
  columns.forEach(col => shuffle(col));
  // we need to pick total 15 numbers, exactly 5 per row, and per column at most 3 numbers (since 3 rows)
  // Standard algorithm: pick a column count distribution that results in 15 numbers across 9 columns with each row 5 numbers
  // Simpler workable method: repeatedly fill rows ensuring each row hits 5 numbers and obey column ranges.
  // Build an empty 3x9 grid of nulls
  const rows = [Array(9).fill(null), Array(9).fill(null), Array(9).fill(null)];
  // We will select 15 columns (positions) so that each row has 5 columns selected, and no column has more than 3 selections
  // Strategy: choose 5 columns per row randomly, but avoid making a column have >3
  const colCounts = Array(9).fill(0);
  for (let r=0; r<3; r++){
    // pick 5 distinct columns for this row, preferring columns with lower counts
    const chosen = [];
    const avail = Array.from({length:9}, (_,i)=>i);
    shuffle(avail);
    for (const c of avail){
      if (chosen.length >= 5) break;
      if (colCounts[c] < 3) {
        chosen.push(c);
        colCounts[c]++;
      }
    }
    // assign a number from that column to rows[r][c]
    for (const c of chosen){
      // pop a number from column bucket
      const n = columns[c].pop();
      rows[r][c] = n;
    }
  }
  // Now rows have numbers and nulls; ensure each row has 5 numbers
  // Flatten to array of numbers
  const numbers = [];
  for (let r=0; r<3; r++){
    for (let c=0; c<9; c++){
      if (rows[r][c] !== null) numbers.push(rows[r][c]);
    }
  }
  numbers.sort((a,b)=>a-b);
  return {
    ticketId: `${idPrefix}-${idx+1}`,
    rows,
    numbers,
    owner: null,
    marked: []
  };
}

// Utility functions
function range(a,b){ const arr=[]; for(let i=a;i<=b;i++) arr.push(i); return arr; }
function shuffle(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }

// Winner detection
function checkWinners(game) {
  // Ensure winners structure exists
  game.winners = game.winners || { quickFive: [], line1: [], line2: [], line3: [], fullHouse: [] };
  const drawnSet = new Set(game.drawnNumbers || []);
  const newly = { quickFive: [], line1: [], line2: [], line3: [], fullHouse: [] };

  for (const ticket of game.tickets) {
    const markedNumbers = ticket.numbers.filter(n => drawnSet.has(n));
    const markedCount = markedNumbers.length;

    // Quick Five: first time reaching >=5
    if (markedCount >= 5) {
      const already = (game.winners.quickFive || []).some(w => w.ticketId === ticket.ticketId);
      if (!already) {
        const w = {
          ticketId: ticket.ticketId,
          owner: ticket.owner,
          markedNumbers,
          amount: game.prizeAmounts.quickFive,
          time: new Date().toISOString()
        };
        newly.quickFive.push(w);
      }
    }

    // Lines: check each row fully marked (row has 5 numbers)
    for (let r=0;r<3;r++){
      const row = ticket.rows[r].filter(v=>v!==null);
      if (row.length === 0) continue;
      const allMarked = row.every(n => drawnSet.has(n));
      if (allMarked) {
        const key = r===0 ? 'line1' : r===1 ? 'line2' : 'line3';
        const already = (game.winners[key] || []).some(w => w.ticketId === ticket.ticketId);
        if (!already) {
          const w = {
            ticketId: ticket.ticketId,
            owner: ticket.owner,
            row: r+1,
            markedNumbers: row,
            amount: game.prizeAmounts[key],
            time: new Date().toISOString()
          };
          newly[key].push(w);
        }
      }
    }

    // Full House
    if (markedCount === ticket.numbers.length) {
      const already = (game.winners.fullHouse || []).some(w => w.ticketId === ticket.ticketId);
      if (!already) {
        const w = {
          ticketId: ticket.ticketId,
          owner: ticket.owner,
          markedNumbers,
          amount: game.prizeAmounts.fullHouse,
          time: new Date().toISOString()
        };
        newly.fullHouse.push(w);
      }
    }
  }

  // Merge newly
  for (const k of ['quickFive','line1','line2','line3','fullHouse']) {
    if (!game.winners[k]) game.winners[k] = [];
    if (newly[k].length) game.winners[k].push(...newly[k]);
  }

  // If fullHouse awarded -> game ends
  const categoriesHaveWinner = ['quickFive','line1','line2','line3','fullHouse'].map(k => (game.winners[k] || []).length > 0);
  if (categoriesHaveWinner.every(x => x)) {
    game.status = 'ended';
  }

  return newly;
}

// Broadcast to SSE clients
function broadcast(event) {
  const payload = `data: ${JSON.stringify(event)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch(e) {}
  }
}

// Periodic auto-call mechanism: per running game
const autoCallTimers = {}; // gameId -> timer

function startAutoCall(gameId) {
  if (autoCallTimers[gameId]) return;
  autoCallTimers[gameId] = setInterval(async () => {
    try {
      const game = store.games.find(g => g.id === gameId);
      if (!game) { clearInterval(autoCallTimers[gameId]); delete autoCallTimers[gameId]; return; }
      if (game.status !== 'running') return;
      // pick random not-drawn number
      const available = Array.from({length:90}, (_,i)=>i+1).filter(n => !(game.drawnNumbers||[]).includes(n));
      if (available.length === 0) {
        game.status = 'ended';
        saveStore();
        broadcast({ type:'game-update', game });
        clearInterval(autoCallTimers[gameId]); delete autoCallTimers[gameId];
        return;
      }
      const pick = available[Math.floor(Math.random()*available.length)];
      game.drawnNumbers.push(pick);
      // detect winners
      const newly = checkWinners(game);
      saveStore();
      broadcast({ type:'number-called', number: pick, newly, game });
      // if ended, stop timer
      if (game.status === 'ended') {
        clearInterval(autoCallTimers[gameId]); delete autoCallTimers[gameId];
      }
    } catch (e) { console.error('Auto-call error', e); }
  }, AUTO_CALL_INTERVAL_MS);
}

function stopAutoCall(gameId) {
  if (autoCallTimers[gameId]) {
    clearInterval(autoCallTimers[gameId]);
    delete autoCallTimers[gameId];
  }
}

// Initialize store
loadStore();

/* ----------------------
   API endpoints
   ----------------------*/

// Admin login (simple)
app.post('/api/admin/login', (req,res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    return res.json({ success: true, token: ADMIN_TOKEN });
  }
  return res.status(401).json({ success: false, msg: 'Invalid credentials' });
});

// Create game
app.post('/api/admin/create-game', (req,res) => {
  const auth = (req.headers.authorization || '').split(' ')[1];
  if (auth !== ADMIN_TOKEN) return res.status(401).json({ msg: 'Unauthorized' });

  const { ticketCount, time } = req.body || {};
  if (!ticketCount || ticketCount < 1) return res.status(400).json({ msg: 'ticketCount required' });

  const id = uuidv4();
  const generatedTickets = [];
  for (let i=0;i<ticketCount;i++){
    generatedTickets.push(generateTicket(id, i));
  }

  const { totalRevenue, totalPrize, prizeAmounts } = calcPrizes(ticketCount);

  const game = {
    id,
    ticketCount,
    time: time || new Date().toISOString(),
    ticketPrice: TICKET_PRICE,
    gameCharge: GAME_CHARGE,
    totalRevenue,
    totalPrize,
    prizeAmounts,
    tickets: generatedTickets,
    drawnNumbers: [],
    winners: { quickFive: [], line1: [], line2: [], line3: [], fullHouse: [] },
    status: 'scheduled', // scheduled -> running -> ended
    createdAt: new Date().toISOString()
  };

  store.games.push(game);
  saveStore();

  res.json({ msg: 'Game created', gameId: id, game });
});

// Start game (admin triggers running)
app.post('/api/admin/:gameId/start', (req,res) => {
  const auth = (req.headers.authorization || '').split(' ')[1];
  if (auth !== ADMIN_TOKEN) return res.status(401).json({ msg: 'Unauthorized' });

  const game = store.games.find(g => g.id === req.params.gameId);
  if (!game) return res.status(404).json({ msg: 'Game not found' });
  if (game.status === 'running') return res.status(400).json({ msg: 'Already running' });
  game.status = 'running';
  saveStore();
  // start auto call
  startAutoCall(game.id);
  broadcast({ type: 'game-update', game });
  res.json({ msg: 'Game started', game });
});

// Manual draw number (admin)
app.post('/api/admin/:gameId/draw', (req,res) => {
  const auth = (req.headers.authorization || '').split(' ')[1];
  if (auth !== ADMIN_TOKEN) return res.status(401).json({ msg: 'Unauthorized' });
  const { number } = req.body || {};
  const game = store.games.find(g => g.id === req.params.gameId);
  if (!game) return res.status(404).json({ msg: 'Game not found' });
  if (game.status === 'ended') return res.status(400).json({ msg: 'Game ended' });

  // pick
  const available = Array.from({length:90}, (_,i)=>i+1).filter(n => !(game.drawnNumbers||[]).includes(n));
  let pick;
  if (number) {
    if (!available.includes(number)) return res.status(400).json({ msg: 'Number invalid or already drawn' });
    pick = number;
  } else {
    if (available.length === 0) return res.status(400).json({ msg: 'No numbers left' });
    pick = available[Math.floor(Math.random()*available.length)];
  }

  game.drawnNumbers.push(pick);
  game.status = 'running';
  const newly = checkWinners(game);
  saveStore();
  // broadcast
  broadcast({ type:'number-called', number: pick, newly, game });
  // stop auto if ended
  if (game.status === 'ended') { stopAutoCall(game.id); }
  res.json({ msg: 'Number drawn', number: pick, newly, game });
});

// Get current active game (latest scheduled/running)
app.get('/api/game/current', (req,res) => {
  const g = store.games.slice().reverse().find(g => g.status === 'scheduled' || g.status === 'running');
  if (!g) return res.status(404).json({ msg: 'No active game' });
  res.json(g);
});

// Get game by id
app.get('/api/game/:id', (req,res) => {
  const g = store.games.find(x => x.id === req.params.id);
  if (!g) return res.status(404).json({ msg: 'Game not found' });
  res.json(g);
});

// Get tickets for a game
app.get('/api/game/:id/tickets', (req,res) => {
  const g = store.games.find(x => x.id === req.params.id);
  if (!g) return res.status(404).json({ msg: 'Game not found' });
  res.json({ tickets: g.tickets.map(t => ({ ticketId: t.ticketId, owner: t.owner })) });
});

// Buy (claim) a ticket
app.post('/api/game/:id/buy-ticket', (req,res) => {
  const { name, ticketId } = req.body || {};
  if (!name || !ticketId) return res.status(400).json({ msg: 'name and ticketId required' });
  const g = store.games.find(x => x.id === req.params.id);
  if (!g) return res.status(404).json({ msg: 'Game not found' });
  if (g.status !== 'scheduled') return res.status(400).json({ msg: 'Ticket purchase closed' });

  const ticket = g.tickets.find(t => t.ticketId === ticketId);
  if (!ticket) return res.status(404).json({ msg: 'Ticket not found' });
  if (ticket.owner) return res.status(400).json({ msg: 'Ticket already taken' });

  ticket.owner = { name, boughtAt: new Date().toISOString() };
  saveStore();
  broadcast({ type:'ticket-bought', ticketId, owner: ticket.owner, gameId: g.id });
  res.json({ msg: 'Ticket claimed', ticket });
});

// Get called numbers
app.get('/api/game/:id/called-numbers', (req,res) => {
  const g = store.games.find(x => x.id === req.params.id);
  if (!g) return res.status(404).json({ msg: 'Game not found' });
  res.json({ called: g.drawnNumbers });
});

// Get winners
app.get('/api/game/:id/winners', (req,res) => {
  const g = store.games.find(x => x.id === req.params.id);
  if (!g) return res.status(404).json({ msg: 'Game not found' });
  res.json({ winners: g.winners, status: g.status });
});

// SSE subscribe
app.get('/api/game/:id/subscribe', (req,res) => {
  // Allow any CORS origin
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive'
  });
  res.flushHeaders();

  // initial ping
  res.write('data: {"msg":"connected"}\n\n');

  sseClients.push(res);

  req.on('close', () => {
    const idx = sseClients.indexOf(res);
    if (idx !== -1) sseClients.splice(idx,1);
  });
});

// Shutdown: save
process.on('SIGINT', ()=> {
  console.log('Saving store and exiting...');
  saveStore();
  process.exit();
});

// Start server
app.listen(PORT, () => {
  console.log(`Tambola backend running on port ${PORT}`);
});